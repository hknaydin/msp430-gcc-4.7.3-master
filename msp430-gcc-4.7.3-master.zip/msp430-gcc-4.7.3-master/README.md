msp430-gcc-4.7.3
================
Compiled binary packages of MSP430-GCC version 4.7.3

Compatible Machine:
 - x64 based linux machines

Installation Instructions:
 - Extract the tar in a location: example (/opt/compilers/mspgcc-4.7.3/)
 - Add the location of extracted binary file path (/opt/compilers/mspgcc-4.7.3/MSP430/bin/) path to your systems' enviroment $PATH
 - edit $HOME/.bashrc and add the following line at the end of the file.
    - export PATH=$PATH:/opt/compilers/mspgcc-4.7.3/bin
